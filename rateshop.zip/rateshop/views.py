from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404, redirect, render
from .forms import RatingForm
from .models import Shop
from django.contrib.auth.models import User
from django.conf import settings

from .utils.collab_filtering import *



def shop_list(request):
    print('abcedf............')
    print(request.user)
    '''
        all_user = User.objects.all()
        recomendation_set = {}
        for user in all_user:
            recomendation = user_recommendations(user.username)
            recomendation_set[user.username] = recomendation

    '''

    #print(recomendation_set)
    #User.objects.all()
    return render(request, 'rateshop/shop_list.html', {
        'shop_list': Shop.objects.all(),
        #'recomendation': str(recomendation_set)[1:len(str(recomendation_set))-1],
        'recomendation': user_recommendations(str(request.user))
    })


def shop_detail(request, pk):
    shop = get_object_or_404(Shop, pk=pk)
    return render(request, 'rateshop/shop_detail.html', {
        'shop': shop,
    })


@login_required
def rating_new(request, shop_pk):
    # shop = Shop.objects.get(pk=shop_pk)
    shop = get_object_or_404(Shop, pk=shop_pk)

    if request.method == 'POST':
        form = RatingForm(request.POST)
        if form.is_valid():
            rating = form.save(commit=False)
            rating.shop = shop
            rating.user = request.user
            rating.save()
            rating.shop.calc_score()
            return redirect('rateshop:shop_detail', rating.shop.pk)
    else:
        form = RatingForm()
    return render(request, 'rateshop/rating_form.html', {
        'form': form,
    })

