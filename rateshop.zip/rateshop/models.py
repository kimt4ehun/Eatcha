from django.conf import settings
from django.db import models
from django.core.validators import MinValueValidator, MaxValueValidator
from django.db.models import Avg


# Create your models here.
class Shop(models.Model):
    name = models.CharField(max_length=100)
    menu = models.CharField(max_length=200, blank=True, default='beef')
    def __str__(self):
        return self.name


class Rating(models.Model):

    user = models.ForeignKey(settings.AUTH_USER_MODEL)  # "auth.User"
    shop = models.ForeignKey(Shop)
    score = models.SmallIntegerField(default=0,
        validators=[
            MinValueValidator(0),
            MaxValueValidator(5)
        ])

    class Meta:
        ordering = ['user']

