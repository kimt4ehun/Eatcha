# Data set of people and movies they have rate 
#0 means either they havent watched it yet.
from .produce_dataset import produce_dataset

dataset = produce_dataset()
