from django.apps import AppConfig


class RateshopConfig(AppConfig):
    name = 'rateshop'
